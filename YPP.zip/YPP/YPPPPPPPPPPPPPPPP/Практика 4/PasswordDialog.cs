﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Практика_4
{
    public partial class PasswordDialog : Form
    {
        public string EnteredPassword { get; private set; }

        public PasswordDialog()
        {
            InitializeComponent();
        }

        private void PasswordDialog_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
            EnteredPassword = textBox1.Text;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
