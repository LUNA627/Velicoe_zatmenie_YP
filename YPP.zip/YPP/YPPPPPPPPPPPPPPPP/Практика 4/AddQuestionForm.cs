﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Практика_4
{
    public partial class AddQuestionForm : Form
    {
        public string QuestionText { get; private set; }  
        public List<string> Options { get; private set; } 
        public string[] CorrectAnswers { get; private set; } 
        public string SelectedImagePath { get; private set; } 

        public AddQuestionForm()
        {
            InitializeComponent();
            button3.Click += button3_Click;
        }

        private void AddQuestionForm_Load(object sender, EventArgs e)
        {

        }



        // Кнопка - добавить вопрос
        private void button1_Click(object sender, EventArgs e)
        {
            QuestionText = textBox1.Text.Trim();

            if (string.IsNullOrEmpty(QuestionText))
            {
                MessageBox.Show("Введите текст вопроса!", "Ошибка");
                return;
            }

            // Разбиваем варианты ответов по запятым
            string[] splitOption = textBox2.Text.Split(new char[] {','}, StringSplitOptions.RemoveEmptyEntries);
            List<string> trimOption = new List<string>();
            foreach (string option in splitOption)
            {
                if (!string.IsNullOrEmpty(option.Trim()))
                {
                    trimOption.Add(option.Trim());
                }
            }
            if (trimOption.Count == 0)
            {
                return;
            }

            List<string> correntOptions = new List<string>();

            foreach(object option in checkedListBox1.CheckedItems)
            {
                correntOptions.Add(option.ToString());
            }

            if (correntOptions.Count == 0)
            {
                MessageBox.Show("Выберите хотя бы один правильный ответ!", "Ошибка");
                return;
            }

            Options = trimOption;
            CorrectAnswers = correntOptions.ToArray();

            this.DialogResult = DialogResult.OK;
            this.Close();

        }


        // Кнопка - отмена
        private void button2_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string[] splitOptions = textBox2.Text.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            List<string>trimOption = new List<string>();

            foreach (string option in splitOptions)
            {
                if (!string.IsNullOrEmpty(option.Trim()))
                {
                    trimOption.Add(option.Trim());
                } 
            }

            checkedListBox1.Items.Clear();
            foreach (string option in trimOption)
            {
                checkedListBox1.Items.Add(option);
            }
        }



        // Кнопка - добавить изображение
        private void button3_Click(object sender, EventArgs e)
        {
            using (var openFileDialog = new OpenFileDialog())
            {
           
                openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png";
                openFileDialog.Title = "Выберите изображение для вопроса";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string imagePath = openFileDialog.FileName;

                    if (File.Exists(imagePath))
                    {
                        pictureBox1.Image = Image.FromFile(imagePath);
                        pictureBox1.SizeMode = PictureBoxSizeMode.Zoom; 

                        SelectedImagePath = imagePath;
                    }
                    else
                    {
                        MessageBox.Show("Файл не найден!", "Ошибка");
                    }
                }
            }
        }




    }
}
