﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практика_4
{
    class TestResults
    {

        public string StudentName { get; set; }
        public string Group { get; set; }
        public double Ball { get; set; }
        public double MaxBall { get; set; }
        public double Percent { get; set; }


       public TestResults(string studentName, string group, double ball, double maxBall, double procent)
        {
            StudentName = studentName;
            Group = group;
            Ball = ball;
            MaxBall = maxBall;
            Percent = procent;
        }
    }
}
