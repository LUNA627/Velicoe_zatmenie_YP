﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практика_4
{
    class Question
    {
        public string Text { get; set; } = ""; // Текст вопроса
        public List<string> Options { get; set; } = new List<string>();// Варианты ответов
        public string[] CorrectAnswers { get; set; } // Правильные ответы
        public string ImagePath { get; set; } = ""; // Путь к изображению
    }
}
