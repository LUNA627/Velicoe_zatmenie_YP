﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Практика_4
{
    public partial class EditQuestionsForm: Form
    {
        List<Question> questions = new List<Question>(); 

        string FilePath = "questions.txt";

        public EditQuestionsForm()
        {
            InitializeComponent();
            this.Load += EditQuestionsForm_Load;
        }

        // Загрузка вопросов при открытии формы
        private void EditQuestionsForm_Load(object sender, EventArgs e)
        {
            LoadQuestions();
            UpdateQuestions();
        }


        // Кнопка - Удалить вопрос
        private void button1_Click_1(object sender, EventArgs e)
        {
            if (listBox1.SelectedItems != null)
            {
                questions.RemoveAt(listBox1.SelectedIndex);
                UpdateQuestions();
            }
            else
            {
                MessageBox.Show("Выберите вопрос для удаления!", "Ошибка");
            }
        
        }





        // Отображение вариантов ответов при выборе вопроса
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItems != null)
            {
                int selectedIndex = listBox1.SelectedIndex;
                Question selectedQuestion = questions[selectedIndex];

                dataGridView1.Rows.Clear();

                foreach (var option in selectedQuestion.Options)
                {
                    bool IsCorrect = selectedQuestion.CorrectAnswers.Contains(option);
                    dataGridView1.Rows.Add(option, IsCorrect);
                }
            }
        }


        // Метод для загрузки вопросов из файла
        private List<Question> LoadQuestions()
        {
            this.questions.Clear();
            try
            {
                using (StreamReader file = new StreamReader(FilePath))
                {
                    while (!file.EndOfStream)
                    {
                        Question question = new Question();

                        bool IsQuestionValid = false;

                        while (question.ImagePath == String.Empty)
                        {
                            string line = file.ReadLine();

                            if (line == null)
                            {
                                break;
                            }

                            if (line.StartsWith("+"))
                            {
                                question.Text = line.Remove(0, 1);
                                IsQuestionValid = true;
                            }

                            else if (line.StartsWith("-"))
                            {
                                question.Options.Add(line.Remove(0, 1));
                            }

                            else if (line.StartsWith("!"))
                            {
                                question.CorrectAnswers = line.Remove(0, 1).Split('|');
                            }

                            else if (line.StartsWith("@"))
                            {
                                question.ImagePath = line.Remove(0, 1);
                                break;
                            }
                        }

                        if (IsQuestionValid)
                        {
                            questions.Add(question);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке вопросов: {ex.Message}", "Ошибка");
            }

            return this.questions; 
        }




        // Кнопка - Сохранить 
        private void button2_Click(object sender, EventArgs e)
        {
            SaveQuestions(questions);
        }


        // Метод для сохранения вопросов в файл
        private void SaveQuestions(List<Question> questions)
        {
            try
            {
                using (var writer = new StreamWriter(FilePath))
                {
                    foreach (var question in questions)
                    {
                        writer.WriteLine($"+{question.Text}");

                        foreach (var option in question.Options)
                        {
                            writer.WriteLine($"-{option}");
                        }

                       writer.WriteLine($"!{string.Join("|", question.CorrectAnswers)}");
              
                        writer.WriteLine($"@{question.ImagePath ?? "Stop"}");

                    }
                }
                MessageBox.Show("Вопросы успешно сохранены!", "Успех");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении вопросов: {ex.Message}", "Ошибка");
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        // Кнопка - Добавить новый вопрос
        private void button3_Click(object sender, EventArgs e)
        {
            using (var addForm = new AddQuestionForm())
            {
                if (addForm.ShowDialog() == DialogResult.OK)
                {
                    var newQuestion = new Question
                    {
                        Text = addForm.QuestionText,
                        Options = addForm.Options,
                        CorrectAnswers = addForm.CorrectAnswers,
                        ImagePath = addForm.SelectedImagePath

                    };
                    questions.Add(newQuestion);
                    UpdateQuestions();
                }
            }
        }


        private void UpdateQuestions()
        {
            listBox1.Items.Clear();
            foreach (Question question in questions)
            {
                listBox1.Items.Add(question.Text);
            }
            
        }
    }
}
