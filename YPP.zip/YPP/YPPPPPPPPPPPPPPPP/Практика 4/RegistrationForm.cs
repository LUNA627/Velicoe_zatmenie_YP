﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Практика_4
{
    public partial class RegistrationForm: Form
    {
        public string StudentName { get; private set; }
        public string StudentGroup { get; private set; }


        private const string CorrectPassword = "admin123";

        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void RegistrationForm_Load(object sender, EventArgs e)
        {

        }

        // Кнопка - Начать тест
        private void butStartTest_Click(object sender, EventArgs e)
        {
           

            if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtGroup.Text))
            {
                MessageBox.Show("Введите имя и группу!", "Ошибка");
                return;
            }

            StudentName = txtName.Text;
            StudentGroup = txtGroup.Text;

            foreach (char c in StudentName)
            {
                if (!char.IsLetter(c) && c != ' ')
                {
                    MessageBox.Show("Имя должно состоять только из букв!", "Ошибка");
                    return;
                }
            }
            this.DialogResult = DialogResult.OK;
            this.Close();
            

        }


        // Кнопка - Режим редактирования
        private void button1_Click_1(object sender, EventArgs e)
        {
          
            using (var passwordDialog = new PasswordDialog())
            {
                if (passwordDialog.ShowDialog() == DialogResult.OK)
                {
                   
                    string enteredPassword = passwordDialog.EnteredPassword;

                    if (enteredPassword == CorrectPassword)
                    {
                      
                        using (var editForm = new EditQuestionsForm())
                        {
                            editForm.ShowDialog();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Неверный пароль!", "Ошибка");
                    }
                }
            }
        }


        private void txtName_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
