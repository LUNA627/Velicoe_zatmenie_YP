﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Практика_4
{
    public partial class ResultForm: Form
    {
        public ResultForm()
        {
            InitializeComponent();
            InitializeDataGridView();
        }



        // Инициализация таблицы
        private void InitializeDataGridView()
        {
            dataGridView1.Columns.Clear(); 

            dataGridView1.Columns.Add("StudentName", "ФИО студента");
            dataGridView1.Columns.Add("Group", "Группа");
            dataGridView1.Columns.Add("Ball", "Набранный балл");
            dataGridView1.Columns.Add("MaxBall", "Максимальный балл");
            dataGridView1.Columns.Add("Percent", "Процент");
            dataGridView1.Columns["Percent"].DefaultCellStyle.Format = "F1";
            dataGridView1.Columns["MaxBall"].DefaultCellStyle.Format = "F1";

            dataGridView1.Columns["StudentName"].Width = 100;
            dataGridView1.Columns["Group"].Width = 150;
            dataGridView1.Columns["Ball"].Width = 120;
            dataGridView1.Columns["MaxBall"].Width = 120;
            dataGridView1.Columns["Percent"].Width = 100;

        }


        // Метод для загрузки результатов в таблицу
        private void ResultForm_Load(object sender, EventArgs e)
        {
            string filePath = "results.txt";

            if (!File.Exists(filePath))
            {
                return;
            }
            var lines = File.ReadAllLines(filePath);

            foreach(var line in lines)
            {
                var parts = line.Split(';');
                if (parts.Length >= 5)
                {
                    try
                    {
                        dataGridView1.Rows.Add(
                            parts[0], 
                            parts[1], 
                            double.Parse(parts[2]), 
                            double.Parse(parts[3]), 
                            double.Parse(parts[4]) 
                        );
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при чтении строки - {line}\n{ex.Message}", "Ошибка");
                    }
                }
               
            }
        }


        // Кнопка для закрытия программы
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
