﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Практика_4
{
    public partial class Form1: Form
    {

        private PictureBox pictureBoxQuestion;

        private string studentName; 
        private string studentGroup; 

        string FilePath = "questions.txt";


        public Form1(string studentName, string studentGroup)
        {
            InitializeComponent();
            this.studentName = studentName;
            this.studentGroup = studentGroup;

          
            pictureBoxQuestion = this.Controls.Find("questionImage", true).FirstOrDefault() as PictureBox;
        }

        // Список всех вопросов теста
        List<Question> questions = new List<Question>();

        int currQuestion = 0; // Текущий вопрос 
        double totalScore = 0; 



        // Загрузка вопросов из файла
        private void Form1_Load(object sender, EventArgs e)
        {
            PictureBox pictureBox = new PictureBox();

            pictureBox.Name = "questionImage";
            pictureBox.Size = new Size(200, 200);
            pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox.Top = label1.Top + label1.Height + 50;
            pictureBox.Left = label1.Left + 450;
            pictureBox.Visible = false;
            this.Controls.Add(pictureBox);


          
            LoadQuestions();
            ShowQuestion(0);
        }



        // Метод для загрузки вопросов
        private void LoadQuestions()
        {
            try
            {
                using (var file = new StreamReader(FilePath))
                {
                    while (!file.EndOfStream)
                    {
                        var question = new Question();
                        bool isQuestionValid = false;

                        while (question.ImagePath == String.Empty)
                        {
                            string line = file.ReadLine();
                            if (line == null) break;

                            if (line.StartsWith("+"))
                            {
                                question.Text = line.Remove(0, 1);
                                isQuestionValid = true;
                            }

                            else if (line.StartsWith("-"))
                            {
                                question.Options.Add(line.Remove(0, 1));
                            }

                            else if (line.StartsWith("!"))
                            {
                                question.CorrectAnswers = line.Remove(0, 1).Split('|');

                            }

                            else if (line.StartsWith("@"))
                            {
                                question.ImagePath = line.Remove(0, 1);
                                break;
                            }
                        }
                        if (isQuestionValid)
                        {
                            questions.Add(question);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при чтении вопросов - {ex}", "Ошибка");
                return;
            }


            ShuffleQuestions();
        }


        // Метод для перемешивания вопросов
        private void ShuffleQuestions()
        {
            Random rand = new Random();
            int n = questions.Count;
            while (n > 1)
            {
                n--;
                int k = rand.Next(n + 1);
                Question value = questions[k];
                questions[k] = questions[n];
                questions[n] = value;
            }
        }


        //Метод - показ вопросов
        private void ShowQuestion(int index)
        {
            if (index < 0 || index >= questions.Count)
            {
                TestResult();
                return;
            }

           
            currQuestion = index;
            this.Text = $"Вопрос {currQuestion + 1} из {questions.Count}";
            label1.Text = questions[currQuestion].Text;

            // Заполняем CheckedListBox вариантами ответов
            checkedListBox1.Items.Clear();
            for (int i = 0; i < questions[currQuestion].Options.Count; i++)
            {
                checkedListBox1.Items.Add(questions[currQuestion].Options[i]);
            }

            // Очистка выбранных ответов
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                checkedListBox1.SetItemChecked(i, false);
            }

           
            var pictureBox = this.Controls.Find("questionImage", true).FirstOrDefault() as PictureBox;
            if (pictureBox != null)
            {
                if (!string.IsNullOrEmpty(questions[currQuestion].ImagePath) && File.Exists(questions[currQuestion].ImagePath))
                {
                    try
                    {
                        pictureBox.Image = Image.FromFile(questions[currQuestion].ImagePath);
                        pictureBox.Visible = true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при загрузке изображения - {ex.Message}", "Ошибка");
                        pictureBox.Visible = false;
                        pictureBox.Image = null;
                    }
                }
                else
                {
                    pictureBox.Visible = false;
                    pictureBox.Image = null;
                }
            }
        }


        // Метод для обработки ответов пользователя
        private void button1_Click(object sender, EventArgs e)
        {
            // выбранные ответы
            var selectedAnswers = new List<string>();
            foreach (var item in checkedListBox1.CheckedItems)
            {
                selectedAnswers.Add(item.ToString());
            }


            double questionScore = 0; 
            var question = questions[currQuestion];


            // каждый правильный ответ - 0.5 балла
            foreach (var answer in selectedAnswers)
            {
                if (question.CorrectAnswers.Contains(answer))
                {
                    questionScore += 0.5;
                }
            }

            totalScore += questionScore;

            ShowQuestion(currQuestion + 1);
        }


        // Метод для сохранения результатов
        private void SaveResultsTofile(TestResults testResults)
        {
            string filePath = "results.txt";

            bool fileExists = File.Exists(filePath);
            if (!fileExists) return;

            using (var writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine($"{testResults.StudentName};{testResults.Group};{testResults.Ball};{testResults.MaxBall};{testResults.Percent}");
            }
        }

        // Метод для окончания теста
        private void TestResult()
        {

          
            double maxPossibleScore = 0;
            foreach (var question in questions)
            {
                maxPossibleScore += question.CorrectAnswers.Length * 0.5;
            }

            double procent = (totalScore / maxPossibleScore) * 100;
            string resultMessage = $"Тест завершен!\n" +
                                    $"Баллов набрано {totalScore} из {maxPossibleScore}\n" +
                                    $"Процент правильных ответов {procent:F1}%\n";

            MessageBox.Show(resultMessage, "Результаты теста", MessageBoxButtons.OK, MessageBoxIcon.Information);


            var result = new TestResults(studentName, studentGroup, totalScore, maxPossibleScore, procent);
            SaveResultsTofile(result);

            ResultForm resultForm = new ResultForm();
            resultForm.ShowDialog();
            this.Close();


            checkedListBox1.Visible = false;
            button1.Visible = false;
            label1.Visible = false;

            
        }


   

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
