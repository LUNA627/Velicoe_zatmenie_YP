﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prack_7
{
    public class GameResult
    {
        public string PlayerName { get; set; }
        public string LevelName { get; set; }
        public string Time { get; set; }
        public int Move { get; set; }
    }
}
