﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prack_7
{
    public partial class Registration : Form
    {
        static List<GameResult> results = new List<GameResult>();

        public Registration()
        {
            InitializeComponent();
            SetupDataGrid();
            LoadResultGrid();
        }

        private void SetupDataGrid()
        {
            dataGridView1.Columns.Add("Level", "Уровень");
            dataGridView1.Columns.Add("Name", "Имя");
            dataGridView1.Columns.Add("Time", "Время");
            dataGridView1.Columns.Add("Moves", "Ходы");

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
        }

        private void LoadResultGrid()
        {
            dataGridView1.Rows.Clear();
            foreach (var row in results)
            {
                dataGridView1.Rows.Add(row.LevelName, row.PlayerName, row.Time, row.Move);
            }
        }




        private void Registration_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            StartGame(1);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            StartGame(2);
        }
        private void button3_Click(object sender, EventArgs e)
        {
            StartGame(3);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            StartGame(4);
        }

        private void StartGame(int level)
        {
            string name = textBox1.Text.Trim();

            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Введите имя", "Ошибка");
                return;
            }

            var game = new Form1(name, level, GameOverResult);
            game.Show();
           

        }

        private void GameOverResult(GameResult result)
        {
            results.Add(result);

            this.Show();
            LoadResultGrid();
        }

        
    }
}
