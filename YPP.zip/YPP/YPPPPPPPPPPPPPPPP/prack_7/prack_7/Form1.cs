﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace prack_7
{
    public partial class Form1 : Form
    {

        private TableLayoutPanel tableLayoutPanel1;
        Random rand = new Random();
        private Label firstClick = null;
        private Label secondClick = null;
        private Timer gameTimer;
        private Timer hideTimer;
        private Action<GameResult> finishGame;

        private int moveCount = 0;
        private int secondTime = 0;
       
        private string playerName;
        private int level;
        bool canClick = true;

        private string[] simbols = {
            "!", "N", ",", "k", "b", "v", "w", "z",
            "a", "c", "q", "d", "e", "r", "s", "t",
            "m", "=", ".", "/", "[", "]", "p", "i"
        };

        public Form1(string _name, int _level, Action<GameResult> finishBack)
        {
            InitializeComponent();
            playerName = _name;
            level = _level;
            finishGame = finishBack;
            SetupGame();
        }

        private void SetupGame()
        {
            int rows = 2;
            int cols = 4; 
            int pairs = 4;

            if (level == 1)
            {
                rows = 2;
                cols = 4;
                pairs = 4;
            }

            else if (level == 2)
            {
                rows = 3;
                cols = 4;
                pairs = 6;
            }

            else if (level == 3)
            {
                rows = 4;
                cols = 4;
                pairs = 8;
            }

            else if (level == 4)
            {
                rows = 6;
                cols = 6;
                pairs = 18;
            }


            List<string> icons = new List<string>();
            for (int i = 0; i < pairs; i++)
            {
                icons.Add(simbols[i]);
                icons.Add(simbols[i]);
            }

            ShuffleList(icons);

            CreatTableLayoutPanel(rows, cols, icons);

            gameTimer = new Timer();
            gameTimer.Interval = 1000;
            gameTimer.Tick += GameTimer_Tick;

            gameTimer.Start();

            hideTimer = new Timer();
            hideTimer.Interval = 500;
            hideTimer.Tick += HideTimer_Tick;

            this.Text = "Парные карточки - " + playerName;
        }


        private void ShuffleList(List<string> list)
        {
            for (int i = list.Count - 1; i > 0; i--)
            {
                int j = rand.Next(i + 1);
                string temp = list[i];
                list[i] = list[j];
                list[j] = temp;
            }
        }


        private void CreatTableLayoutPanel(int rows, int cols, List<string> icons)
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.Inset;
            tableLayoutPanel1.BackColor = Color.LightCoral;

            tableLayoutPanel1.ColumnCount = cols;
            tableLayoutPanel1.RowCount = rows;

            for (int i = 0; i < cols; i++)
            {
                tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / cols));
            }

            for (int i = 0; i < rows; i++)
            {
                tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100f / cols));
            }

            int index = 0;

            for (int r = 0; r < rows; r++)
            {
                for (int c = 0; c < cols; c++)
                {
                    Label cell = new Label();
                    cell.Dock = DockStyle.Fill;
                    cell.Font = new Font("Webdings", 52, FontStyle.Bold);
                    cell.TextAlign = ContentAlignment.MiddleCenter;
                    cell.ForeColor = Color.LightCoral;
                    cell.BackColor = Color.LightCoral;
                    cell.Text = icons[index];
                    index++;

                    cell.Click += Cell_Click;
                    tableLayoutPanel1.Controls.Add(cell, c, r);

                }
            }
            this.Controls.Add(tableLayoutPanel1);
        }


        private void Cell_Click(object sender,  EventArgs e)
        {
            
            Label clicked = (Label)sender;

            if (clicked.ForeColor != Color.LightCoral)
            {
                return;
            }

            if (!canClick || firstClick == sender)
            {
                return;
            }

            clicked.ForeColor = Color.Black;

            if (firstClick == null)
            {
                firstClick = clicked;
                return;
            }


            secondClick = clicked;
            moveCount++;
            canClick = false;

            if (firstClick.Text == secondClick.Text)
            {
                firstClick = null;
                secondClick = null;
                canClick = true;
                CheckWin();
            }
            else
            {
                hideTimer.Start();
            }
        }


        private void HideTimer_Tick(object sender, EventArgs e)
        {
            firstClick.ForeColor = Color.LightCoral;
            secondClick.ForeColor = Color.LightCoral;
            canClick = true;
            firstClick = null;
            secondClick = null;

            hideTimer.Stop();
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            secondTime++;
        }


        private void CheckWin()
        {
            for (int i = 0; i < tableLayoutPanel1.Controls.Count; i++)
            {
                Control control = tableLayoutPanel1.Controls[i];
                if (control is Label label)
                {
                    if (label.ForeColor == Color.LightCoral)  return;
                }
            }

            gameTimer.Stop();

            string levelName = "";
            if (level == 1)
            {
                levelName = "Легкий";
            }
            else if (level == 2)
            {
                levelName = "Нормальный";
            }
            else if (level == 3)
            {
                levelName = "Сложный";
            }
            else if (level == 4)
            {
                levelName = "Невозможно";
            }

                string timeResult = string.Format("{0:D2}:{1:D2}", secondTime / 60, secondTime % 60);

            var result = new GameResult();
            result.LevelName = levelName;
            result.PlayerName = playerName;
            result.Time = timeResult;
            result.Move = moveCount;


            finishGame(result);

            MessageBox.Show("ПОБЕДА", "Успех");

            this.Close();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
