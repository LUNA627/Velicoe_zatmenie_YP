﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prack_8
{
    public partial class Registation : Form
    {
        private List<GameResult> results = new List<GameResult>();
        private string playerName = "";
        private int selSize = 0;
        public Registation()
        {
            InitializeComponent();
            InitializeResultsGrid();
        }

        private void InitializeResultsGrid()
        {
            dataGridView1.Columns.Clear();
            dataGridView1.Columns.Add("PlayerName", "Игрок");
            dataGridView1.Columns.Add("Size", "Уровнь");
            dataGridView1.Columns.Add("Moves", "Ходы");

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
        }

        private void UpdateResultsGrid()
        {
            dataGridView1.Rows.Clear();

            foreach(var result in results)
            {
                dataGridView1.Rows.Add(result.PlayerName, $"{result.Size}x{result.Size}", result.Moves);
            }

 
        }


        internal void AddResult(string playerName, int size, int moves)
        {
            results.Add(new GameResult
            {
                PlayerName = playerName,
                Size = size,
                Moves = moves
            });
           UpdateResultsGrid();    
        }



        private void Registation_Load(object sender, EventArgs e)
        {

        }

        private void UpdateStartPlay()
        {
            button6.Enabled = (!string.IsNullOrWhiteSpace(playerName));
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            if ( !string.IsNullOrWhiteSpace(playerName))
            {
                var gameForm = new GameForm(selSize, playerName, this);
                gameForm.FormClosed += (s, args) => this.Show();
                this.Hide();
                gameForm.Show();
            }
            else
            {
                MessageBox.Show("Выберите уровень и введите имя!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        private void LevelButton(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;

            // Сброс фона у всех кнопок уровней
            foreach (Control control in Controls)
            {
                if (control is Button btn &&
                    (btn.Text == "2x2" || btn.Text == "3x3" || btn.Text == "4x4" || btn.Text == "5x5" || btn.Text == "6x6"))
                {
                    btn.BackColor = SystemColors.Control;
                }
            }

            clickedButton.BackColor = Color.LightBlue;

            
            switch (clickedButton.Text)
            {
                case "2x2": selSize = 2; 
                    break;
                case "3x3": selSize = 3; 
                    break;
                case "4x4": selSize = 4; 
                    break;
                case "5x5": selSize = 5; 
                    break;
                case "6x6": selSize = 6; 
                    break;
            }

            UpdateStartPlay();
        }


        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            playerName = textBox1.Text.Trim();
            UpdateStartPlay();
        }
    }
}
