﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Runtime.Remoting;
using System.Text;
using System.Threading.Tasks;

namespace prack_8
{
    internal class Game
    {
        private Random rand = new Random();
        public int Size { get; private set; }
        private int[,] map;
        private int spaceX, spaceY;


        public Game(int size)
        {
            if (size < 2) size = 2;
            if (size > 6) size = 6;

            Size = size;
            map = new int[size, size];
        }

        private int _moveCount = 0;
        public int MoveCount => _moveCount;

        public void Start()
        {
            _moveCount = 0;

            int num = 1;

            for (int y = 0; y < Size; y++)
            {
                for (int x = 0; x < Size; x++)
                {
                    if (num == (Size * Size))
                    {
                        map[x, y] = 0;
                    }
                    else
                    {
                        map[x, y] = num;
                    }
                    num++;
                }
            }

            spaceX = Size - 1;
            spaceY = Size - 1;
        }


        public int GetNumbers(int position)
        {
            int x = position % Size;
            int y = position / Size;
            return map[x, y];
        }


        public void Move(int position)
        {
            if (position < 0 || position >= Size * Size) return;

            int x = position % Size;
            int y = position / Size;

            int dx = Math.Abs(spaceX - x);
            int dy = Math.Abs(spaceY - y);

            if (dx + dy != 1) return;

            map[spaceX, spaceY] = map[x, y];
            map[x, y] = 0;

            spaceX = x;
            spaceY = y;

            _moveCount++;

        }

        public void Shuffle()
        {
            Start();

            for (int i = 0; i < 100; i++)
            {
                int gen = rand.Next(4);

                int posX = spaceX;
                int posY = spaceY;

                switch(gen)
                {
                    case 0: posX--; break; 
                    case 1: posX++; break; 
                    case 2: posY--; break; 
                    case 3: posY++; break; 
                }

                if (posX >= 0 && posX < Size && posY >= 0 && posY < Size)
                {
                    int temp = map[spaceX, spaceY];
                    map[spaceX, spaceY] = map[posX, posY];
                    map[posX, posY] = temp;

                    spaceX = posX;
                    spaceY = posY;
                }
                _moveCount = 0;
            }
        }


        public bool IsWin()
        {
            int num = 1;

            for (int x = 0; x < Size; x++)
            {
                for (int y = 0; y < Size; y++)
                {
                    if (map[y, x] != num % (Size * Size))
                    {
                        return false;
                    }
                    num++;
                }
            }
            return true;
        }
    }
}
