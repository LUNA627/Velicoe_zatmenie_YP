﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prack_8
{
    public partial class GameForm : Form
    {
        private Game game;
        private TableLayoutPanel tableLayoutPanel;
        private Registation registration;
        private int size;
        private string namePlayer;
    

        public GameForm(int size, string namePlayer, Registation registation)
        {
            InitializeComponent();
            this.size = size;
            this.namePlayer = namePlayer;
            this.registration = registation;

            StartUI();    
            NewGame();
        }

        private void StartUI()
        {
            this.Text = $"Пятнашки - {size}x{size}";
            this.Size = new Size(400, 450);
            this.StartPosition = FormStartPosition.CenterScreen;

            tableLayoutPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = size,
                RowCount = size,
                Padding = new Padding(10)
            };

            for (int i = 0; i < size; i++)
            {
                tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / size));
                tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f / size));
            }

            this.Controls.Add(tableLayoutPanel);
        }

        private void UpdateUI()
        {
            this.Text = $"Пятнашки — {size}×{size} | Ходов: {game.MoveCount}";

            tableLayoutPanel.Controls.Clear();

            for (int pos = 0; pos < size * size; pos++)
            {
                int value = game.GetNumbers(pos);

                var button = new Button
                {
                    Text = value == 0 ? "" : value.ToString(),
                    Dock = DockStyle.Fill,
                    Font = new Font("Arial", 14F),
                    Tag = pos,
                    Margin = new Padding(2)
                };
                button.Click += MoveButton_Click;
                tableLayoutPanel.Controls.Add(button);
            }

            if (game.IsWin())
            {
                MessageBox.Show(
                    $"Поздравляем, {namePlayer}!\nВы собрали пятнашки за {game.MoveCount} ходов!","Победа!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                registration.AddResult(namePlayer, size, game.MoveCount);
                this.Close(); 
            }
        }

        private void MoveButton_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            int position = (int)btn.Tag;
            game.Move(position);
            UpdateUI();
        }



        private void NewGame()
        {
            game = new Game(size);
            game.Start();
            game.Shuffle();
            UpdateUI();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
