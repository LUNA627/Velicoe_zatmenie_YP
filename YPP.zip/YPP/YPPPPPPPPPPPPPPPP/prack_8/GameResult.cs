﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prack_8
{
    public class GameResult
    {
        public string PlayerName { get; set; }
        public int Size { get; set; }
        public int Moves { get; set; }
    }
}
