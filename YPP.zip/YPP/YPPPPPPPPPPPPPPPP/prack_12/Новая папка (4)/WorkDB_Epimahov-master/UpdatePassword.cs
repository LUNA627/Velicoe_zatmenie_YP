﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkDB_Epimahov
{
    public partial class UpdatePassword : Form
    {
        int id;
        SqlConnection connect = new SqlConnection(@"Data Source=PC325L-11\SQLEXPRESS;Initial Catalog=SecurityDB_Epimahov;Integrated Security=True");
        public UpdatePassword(int id)
        {
            InitializeComponent();
            this.id = id;
        }

        private void UpdatePass_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void ChangePass_Click(object sender, EventArgs e)
        {
            string oldpass = OldPass.Text;
            string newpass = NewPass.Text;
            string confirm = NewPassConfirm.Text;
            if (oldpass == newpass)
                MessageBox.Show("Старый и новый пароли не должны совпадать", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (newpass != confirm)
                MessageBox.Show("Новый пароль не подтвержден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                connect.Open();
                string query1 = "select count(*) " +
                    "from User_tbl " +
                    "where Password = @oldpass and id = @id";
                SqlCommand command1 = new SqlCommand(query1, connect);
                command1.Parameters.AddWithValue("@oldpass", oldpass);
                command1.Parameters.AddWithValue("@id", id);
                int count = (int)command1.ExecuteScalar();
                if (count > 0)
                {
                    string query2 = "update User_tbl " +
                    "set Password = @newpass, date = getdate() " +
                       "where ID = @id";
                    SqlCommand command2 = new SqlCommand(query2, connect);
                    command2.Parameters.AddWithValue("@newpass", newpass);
                    command2.Parameters.AddWithValue("@id", id);
                    command2.ExecuteNonQuery();
                    MessageBox.Show("Пароль изменен", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
                else
                    MessageBox.Show("Неверный старый пароль", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                connect.Close();
            }
        }
    }
}
