﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkDB_Epimahov
{
    public partial class Root : Form
    {
        public Root()
        {
            InitializeComponent();
        }

        private void Root_frm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void Root_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("мемс.jpg");

            pictureBox1.Name = "mems";
            pictureBox1.Size = new Size(250, 250);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
          

        }
    }
}
