﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkDB_Epimahov
{
    public partial class Admin : Form
    {
        private string connect = @"Data Source=DENIS;Initial Catalog=SecurityDB_Epimakhov;Integrated Security=True;";

        public Admin()
        {
            
            InitializeComponent();
        }
        private void UpdateTable()
        {
            UpdateTable("SELECT * FROM User_tbl");
        }

        // Метод для обновления данных в DataGridView 
        private void UpdateTable(string query)
        {
            var table = new DataTable();
            using (var adapter = new SqlDataAdapter(query, connect))
            {
                adapter.Fill(table);
            }
            user_tblDataGridView.DataSource = table;
        }



        private void Admin_frm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); 
        }

        // Обработчик события сохранения изменений через BindingNavigator
        private void user_tblBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate(); 
            this.user_tblBindingSource.EndEdit();                                  
        }

      
        private void Admin_frm_Load(object sender, EventArgs e)
        {
            UpdateTable();
        }

        // Обработчик события нажатия кнопки "Добавить"
        private void Add_Click(object sender, EventArgs e)
        {
          
            string login = Login.Text;
            string password = Pass.Text;
            string role = Role.Text;

           
            if (login == "" || password == "" || role == "")
                MessageBox.Show("Все поля должны быть заполнены", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            if (role != "Admin" && role != "User")
                MessageBox.Show("Неправильная роль (Admin или User)", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            
            try
            {
                if (ExistsLogin(login))
                {
                    MessageBox.Show("Пользователь с таким логином уже существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string insertQuery = @"INSERT INTO dbo.User_tbl (login, password, Count, date, active, role) VALUES (@login, @password, 0, GETDATE(), 'True', @role)";

                using (var conn = new SqlConnection(connect))
                {
                    conn.Open();
                    using (var cmd = new SqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@login", login);
                        cmd.Parameters.AddWithValue("@password", password);
                        cmd.Parameters.AddWithValue(@"role", role);

                        cmd.ExecuteNonQuery();
                    } 
                }
                MessageBox.Show("Пользователь добавлен", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                UpdateTable();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private bool ExistsLogin(string login)
        {
            string query = "SELECT COUNT(1) FROM User_tbl WHERE Login = @login";

            using (var conn = new SqlConnection(connect))
            {
                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@login", login);
                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
        }

        // Обработчик события нажатия кнопки "Сохранить изменения"
        private void Save_Click(object sender, EventArgs e)
        {
            if (user_tblDataGridView.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите пользователя для изменения", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string login = Login.Text;
            string password = Pass.Text;
            string role = Role.Text;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(role))
            {
                MessageBox.Show("Все поля должны быть заполнены", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                int id = (int)user_tblDataGridView.SelectedRows[0].Cells[0].Value;

                string updateQuery = @"UPDATE User_tbl SET Login = @login, Password = @password, Role = @role WHERE id = @id";

                using (var conn = new SqlConnection(connect))
                {
                    conn.Open();
                    using (var cmd = new SqlCommand(updateQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@login", login);
                        cmd.Parameters.AddWithValue("@password", password);
                        cmd.Parameters.AddWithValue("@role", role);
                        cmd.Parameters.AddWithValue("@id", id);

                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Пользователь обновлен");
                UpdateTable();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }






        // Обработчик события нажатия кнопки "Показать заблокированных пользователей"
        private void AllBlocks_Click(object sender, EventArgs e)
        {
            
           UpdateTable("SELECT * FROM user_tbl WHERE Active = 'False'");
        }

        // Обработчик события нажатия кнопки "Показать всех пользователей"
        private void CheckAll_Click(object sender, EventArgs e)
        {
            UpdateTable();
        }

        // Обработчик события нажатия кнопки "Блокировка/Разблокировка пользователя"
        private void Block_Click(object sender, EventArgs e)
        {
            if (user_tblDataGridView.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите пользователя для изменения", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var row = user_tblDataGridView.SelectedRows[0];
            int id = (int)row.Cells[0].Value;
            bool IsActive = (bool)row.Cells[5].Value;

            string query = IsActive ? "UPDATE User_tbl SET Active = 'False' WHERE id = @id" : "UPDATE User_tbl SET Active = 'True' WHERE id = @id";

            try
            {
                using (var conn = new SqlConnection(connect))
                {
                    conn.Open();
                    using(var cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }
                }
                UpdateTable();
            }
            catch(Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Обработчик события нажатия кнопки "Снять все блокировки"
        private void RemoveAllBlocks_Click(object sender, EventArgs e)
        {
            string query = "UPDATE User_tbl SET Active = 'True', Count = 0, date = GETDATE() WHERE Active = 'False'";

            try
            {
                using (var conn = new SqlConnection(connect))
                {
                    conn.Open();
                    using (var cmd = new SqlCommand(query, conn))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }
                UpdateTable();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        // Обработчик события нажатия кнопки "Блокировка пользователей за период"
        private void BlockOnPeriod_Click(object sender, EventArgs e)
        {

            DateTime dateTime1 = dateTimePicker1.Value.Date;
            DateTime dateTime2 = dateTimePicker2.Value.Date;

            string query = @"UPDATE User_tbl SET Active = 'False' WHERE date BETWEEN @date1 AND @date2";
            try
            {
                using (var connection = new SqlConnection(connect))
                {
                    connection.Open();
                    using (var cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@date1", dateTime1);
                        cmd.Parameters.AddWithValue("@date2", dateTime2);
                        cmd.ExecuteNonQuery();
                    }
                }
                UpdateTable();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        // Обработчик события нажатия кнопки "Показать входы за сегодня"
        private void TodayGates_Click(object sender, EventArgs e)
        {
            UpdateTable("SELECT * FROM User_tbl WHERE CONVERT(date, date) = CONVERT(date, GETDATE())");
        }
    }
}
