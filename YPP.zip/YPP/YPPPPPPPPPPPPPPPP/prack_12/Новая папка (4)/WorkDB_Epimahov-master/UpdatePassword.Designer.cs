﻿namespace WorkDB_Epimahov
{
    partial class UpdatePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.OldPass = new System.Windows.Forms.TextBox();
            this.NewPass = new System.Windows.Forms.TextBox();
            this.NewPassConfirm = new System.Windows.Forms.TextBox();
            this.ChangePass = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(97, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(383, 48);
            this.label1.TabIndex = 0;
            this.label1.Text = "Измените пароль Вашей учетной записи,\r\n т.к. Вы не меняли пароль более 14 дней";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(101, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Старый пароль";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(101, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Новый пароль";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(101, 207);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(202, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "Подтвердите пароль";
            // 
            // OldPass
            // 
            this.OldPass.Location = new System.Drawing.Point(314, 113);
            this.OldPass.Name = "OldPass";
            this.OldPass.Size = new System.Drawing.Size(154, 29);
            this.OldPass.TabIndex = 4;
            // 
            // NewPass
            // 
            this.NewPass.Location = new System.Drawing.Point(314, 157);
            this.NewPass.Name = "NewPass";
            this.NewPass.Size = new System.Drawing.Size(154, 29);
            this.NewPass.TabIndex = 5;
            // 
            // NewPassConfirm
            // 
            this.NewPassConfirm.Location = new System.Drawing.Point(314, 205);
            this.NewPassConfirm.Name = "NewPassConfirm";
            this.NewPassConfirm.Size = new System.Drawing.Size(154, 29);
            this.NewPassConfirm.TabIndex = 6;
            // 
            // ChangePass
            // 
            this.ChangePass.Location = new System.Drawing.Point(203, 273);
            this.ChangePass.Name = "ChangePass";
            this.ChangePass.Size = new System.Drawing.Size(205, 35);
            this.ChangePass.TabIndex = 7;
            this.ChangePass.Text = "Изменить пароль";
            this.ChangePass.UseVisualStyleBackColor = true;
            this.ChangePass.Click += new System.EventHandler(this.ChangePass_Click);
            // 
            // UpdatePass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(630, 371);
            this.Controls.Add(this.ChangePass);
            this.Controls.Add(this.NewPassConfirm);
            this.Controls.Add(this.NewPass);
            this.Controls.Add(this.OldPass);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "UpdatePass";
            this.Text = "Измените пароль";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UpdatePass_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox OldPass;
        private System.Windows.Forms.TextBox NewPass;
        private System.Windows.Forms.TextBox NewPassConfirm;
        private System.Windows.Forms.Button ChangePass;
    }
}