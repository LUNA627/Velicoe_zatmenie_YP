﻿namespace WorkDB_Epimahov
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Login = new System.Windows.Forms.TextBox();
            this.Pass = new System.Windows.Forms.TextBox();
            this.Role = new System.Windows.Forms.TextBox();
            this.Add = new System.Windows.Forms.Button();
            //this.securityDB_EpimahovDataSet = new WorkDB_Epimahov.SecurityDB_EpimahovDataSet();
            this.user_tblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            //this.user_tblTableAdapter = new WorkDB_Epimahov.SecurityDB_EpimahovDataSetTableAdapters.User_tblTableAdapter();
            //this.tableAdapterManager = new WorkDB_Epimahov.SecurityDB_EpimahovDataSetTableAdapters.TableAdapterManager();
            this.user_tblDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Save = new System.Windows.Forms.Button();
            this.AllBlocks = new System.Windows.Forms.Button();
            this.Block = new System.Windows.Forms.Button();
            this.CheckAll = new System.Windows.Forms.Button();
            this.RemoveAllBlocks = new System.Windows.Forms.Button();
            this.BlockOnPeriod = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.TodayGates = new System.Windows.Forms.Button();
            //((System.ComponentModel.ISupportInitialize)(this.securityDB_EpimahovDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.user_tblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.user_tblDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Имя пользователя";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 63);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Пароль";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(39, 98);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Роль";
            // 
            // Login
            // 
            this.Login.Location = new System.Drawing.Point(228, 27);
            this.Login.Margin = new System.Windows.Forms.Padding(6);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(180, 29);
            this.Login.TabIndex = 3;
            // 
            // Pass
            // 
            this.Pass.Location = new System.Drawing.Point(228, 68);
            this.Pass.Margin = new System.Windows.Forms.Padding(6);
            this.Pass.Name = "Pass";
            this.Pass.Size = new System.Drawing.Size(180, 29);
            this.Pass.TabIndex = 4;
            // 
            // Role
            // 
            this.Role.Location = new System.Drawing.Point(228, 109);
            this.Role.Margin = new System.Windows.Forms.Padding(6);
            this.Role.Name = "Role";
            this.Role.Size = new System.Drawing.Size(180, 29);
            this.Role.TabIndex = 5;
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(43, 146);
            this.Add.Margin = new System.Windows.Forms.Padding(6);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(162, 42);
            this.Add.TabIndex = 6;
            this.Add.Text = "Добавить";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // securityDB_EpimahovDataSet
            // 
            //this.securityDB_EpimahovDataSet.DataSetName = "SecurityDB_EpimahovDataSet";
            //this.securityDB_EpimahovDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // user_tblBindingSource
            // 
            this.user_tblBindingSource.DataMember = "User_tbl";
            //this.user_tblBindingSource.DataSource = this.securityDB_EpimahovDataSet;
            // 
            // user_tblTableAdapter
            // 
            //this.user_tblTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            //this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            //this.tableAdapterManager.UpdateOrder = WorkDB_Epimahov.SecurityDB_EpimahovDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            //this.tableAdapterManager.User_tblTableAdapter = this.user_tblTableAdapter;
            // 
            // user_tblDataGridView
            // 
            this.user_tblDataGridView.AutoGenerateColumns = false;
            this.user_tblDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.user_tblDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewCheckBoxColumn1,
            this.dataGridViewTextBoxColumn6});
            this.user_tblDataGridView.DataSource = this.user_tblBindingSource;
            this.user_tblDataGridView.Location = new System.Drawing.Point(43, 332);
            this.user_tblDataGridView.Name = "user_tblDataGridView";
            this.user_tblDataGridView.ReadOnly = true;
            this.user_tblDataGridView.Size = new System.Drawing.Size(898, 268);
            this.user_tblDataGridView.TabIndex = 8;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Login";
            this.dataGridViewTextBoxColumn2.HeaderText = "Login";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Password";
            this.dataGridViewTextBoxColumn3.HeaderText = "Password";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Count";
            this.dataGridViewTextBoxColumn4.HeaderText = "Count";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Date";
            this.dataGridViewTextBoxColumn5.HeaderText = "Date";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.DataPropertyName = "Active";
            this.dataGridViewCheckBoxColumn1.HeaderText = "Active";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Role";
            this.dataGridViewTextBoxColumn6.HeaderText = "Role";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(246, 146);
            this.Save.Margin = new System.Windows.Forms.Padding(6);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(162, 42);
            this.Save.TabIndex = 9;
            this.Save.Text = "Сохранить";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // AllBlocks
            // 
            this.AllBlocks.Location = new System.Drawing.Point(436, 113);
            this.AllBlocks.Margin = new System.Windows.Forms.Padding(6);
            this.AllBlocks.Name = "AllBlocks";
            this.AllBlocks.Size = new System.Drawing.Size(197, 60);
            this.AllBlocks.TabIndex = 11;
            this.AllBlocks.Text = "Вывести всех заблокированных";
            this.AllBlocks.UseVisualStyleBackColor = true;
            this.AllBlocks.Click += new System.EventHandler(this.AllBlocks_Click);
            // 
            // Block
            // 
            this.Block.Location = new System.Drawing.Point(436, 27);
            this.Block.Margin = new System.Windows.Forms.Padding(6);
            this.Block.Name = "Block";
            this.Block.Size = new System.Drawing.Size(197, 71);
            this.Block.TabIndex = 12;
            this.Block.Text = "Заблокировать/\r\nРазблокировать";
            this.Block.UseVisualStyleBackColor = true;
            this.Block.Click += new System.EventHandler(this.Block_Click);
            // 
            // CheckAll
            // 
            this.CheckAll.Location = new System.Drawing.Point(43, 200);
            this.CheckAll.Margin = new System.Windows.Forms.Padding(6);
            this.CheckAll.Name = "CheckAll";
            this.CheckAll.Size = new System.Drawing.Size(365, 46);
            this.CheckAll.TabIndex = 13;
            this.CheckAll.Text = "Посмотреть всех пользователей";
            this.CheckAll.UseVisualStyleBackColor = true;
            this.CheckAll.Click += new System.EventHandler(this.CheckAll_Click);
            // 
            // RemoveAllBlocks
            // 
            this.RemoveAllBlocks.Location = new System.Drawing.Point(436, 188);
            this.RemoveAllBlocks.Margin = new System.Windows.Forms.Padding(6);
            this.RemoveAllBlocks.Name = "RemoveAllBlocks";
            this.RemoveAllBlocks.Size = new System.Drawing.Size(197, 60);
            this.RemoveAllBlocks.TabIndex = 14;
            this.RemoveAllBlocks.Text = "Разблокировать всех";
            this.RemoveAllBlocks.UseVisualStyleBackColor = true;
            this.RemoveAllBlocks.Click += new System.EventHandler(this.RemoveAllBlocks_Click);
            // 
            // BlockOnPeriod
            // 
            this.BlockOnPeriod.Location = new System.Drawing.Point(660, 26);
            this.BlockOnPeriod.Margin = new System.Windows.Forms.Padding(6);
            this.BlockOnPeriod.Name = "BlockOnPeriod";
            this.BlockOnPeriod.Size = new System.Drawing.Size(281, 71);
            this.BlockOnPeriod.TabIndex = 15;
            this.BlockOnPeriod.Text = "Заблокировать всех, не заходивших в период";
            this.BlockOnPeriod.UseVisualStyleBackColor = true;
            this.BlockOnPeriod.Click += new System.EventHandler(this.BlockOnPeriod_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(660, 113);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(281, 29);
            this.dateTimePicker1.TabIndex = 16;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(660, 148);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(281, 29);
            this.dateTimePicker2.TabIndex = 17;
            // 
            // TodayGates
            // 
            this.TodayGates.Location = new System.Drawing.Point(43, 258);
            this.TodayGates.Margin = new System.Windows.Forms.Padding(6);
            this.TodayGates.Name = "TodayGates";
            this.TodayGates.Size = new System.Drawing.Size(365, 65);
            this.TodayGates.TabIndex = 18;
            this.TodayGates.Text = "Посмотреть всех пользователей, заходивших сегодня";
            this.TodayGates.UseVisualStyleBackColor = true;
            this.TodayGates.Click += new System.EventHandler(this.TodayGates_Click);
            // 
            // Admin_frm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(963, 660);
            this.Controls.Add(this.TodayGates);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.BlockOnPeriod);
            this.Controls.Add(this.RemoveAllBlocks);
            this.Controls.Add(this.CheckAll);
            this.Controls.Add(this.Block);
            this.Controls.Add(this.AllBlocks);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.user_tblDataGridView);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Role);
            this.Controls.Add(this.Pass);
            this.Controls.Add(this.Login);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Admin_frm";
            this.Text = "Раздел администратора системы";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Admin_frm_FormClosing);
            this.Load += new System.EventHandler(this.Admin_frm_Load);
            //((System.ComponentModel.ISupportInitialize)(this.securityDB_EpimahovDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.user_tblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.user_tblDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Login;
        private System.Windows.Forms.TextBox Pass;
        private System.Windows.Forms.TextBox Role;
        private System.Windows.Forms.Button Add;
        //private SecurityDB_EpimahovDataSet securityDB_EpimahovDataSet;
        private System.Windows.Forms.BindingSource user_tblBindingSource;
        //private SecurityDB_EpimahovDataSetTableAdapters.User_tblTableAdapter user_tblTableAdapter;
        //private SecurityDB_EpimahovDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView user_tblDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Button AllBlocks;
        private System.Windows.Forms.Button Block;
        private System.Windows.Forms.Button CheckAll;
        private System.Windows.Forms.Button RemoveAllBlocks;
        private System.Windows.Forms.Button BlockOnPeriod;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Button TodayGates;
    }
}