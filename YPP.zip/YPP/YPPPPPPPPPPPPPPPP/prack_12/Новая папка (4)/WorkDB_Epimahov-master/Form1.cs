﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace WorkDB_Epimahov
{
    public partial class Authorization_frm : Form
    {

        private string connect = @"Data Source=DENIS;Initial Catalog=SecurityDB_Epimakhov;Integrated Security=True;";
    

        public Authorization_frm()
        {
        
            InitializeComponent();
        }

        private void ClearPoleEnter()
        {
            Login_txt.Text = string.Empty;
            Password_txt.Text = string.Empty;
        }

        private void ClearPoleReg()
        {
             Login.Text = string.Empty;
             Password.Text = string.Empty;
             PassRep.Text = string.Empty;
        }

        // Обработчик события нажатия кнопки "Вход"
        private void Input_btn_Click(object sender, EventArgs e)
        {
            string login = Login_txt.Text;
            string password = Password_txt.Text;

            try
            {
                CheckEmptyEntriesEnter(login, password);
                ValidLogOnPassInBD(login, password);
            }
            catch (Exception ex)
            {
                ClearPoleEnter();
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
          
         
        }



        // Аутентификация
        private int? AuthenticateUser(string login, string pass)
        {
            string query = "SELECT id FROM User_tbl WHERE login = @login AND password = @password";

            using (var connection = new SqlConnection(connect))
            {
                connection.Open();
                using (var commad = new SqlCommand(query, connection))
                {
                    commad.Parameters.AddWithValue("@login", login);
                    commad.Parameters.AddWithValue("@password", pass);

                    return commad.ExecuteScalar() as int?;
                }
            }
        }


        private void FailAttemptEnter(string login)
        {
            int? userId = GetUserById(login);
            if (userId == null)
            {
                return;
            }

            int id = userId.Value;
            IncrementFailAttempt(id);
            if (GetFailAttemptCount(id) >= 3)
            {
                BlockUser(id);
                throw new Exception("ВЫ были заблокированы");
            }
            
        }


        private void BlockUser(int userId)
        {
            string query = "UPDATE User_tbl SET Active = 'False' WHERE id = @id";

            using (var connection = new SqlConnection(connect))
            {
                connection.Open();
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", userId);
                    var result = command.ExecuteScalar();
                    command.ExecuteNonQuery();
                }
            }
        }


        private int GetFailAttemptCount(int userId)
        {
            string query = "SELECT count FROM User_tbl WHERE id = @id";

            using (var connection = new SqlConnection(connect))
            {
                connection.Open();
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", userId);
                    var result = command.ExecuteScalar();
                    return result == null ? 0 : (int)result;
                }
            }
        }

        private void IncrementFailAttempt(int userId)
        {
            string query = "UPDATE User_tbl SET Count = Count + 1 WHERE id = @id";

            using (var connection = new SqlConnection(connect))
            {
                connection.Open();
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", userId);
                    command.ExecuteNonQuery();  
                }
            }
        }

        private int? GetUserById(string login)
        {
            string query = "SELECT id FROM User_tbl WHERE login = @login";

            using (var connection = new SqlConnection(connect))
            {
                connection.Open();
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@login", login);

                    return command.ExecuteScalar() as int?;
                }
            }
        }


        private bool ActiveUser(int userId)
        {
            string query = "SELECT Active FROM User_tbl WHERE id = @id";

            using (var connection = new SqlConnection(connect))
            {
                connection.Open();
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", userId);
                    var result = command.ExecuteScalar();
                    return result != null && (bool)result;
                }
            }
        }


        private void UpdateDateUser(int userId)
        {
            string query = "UPDATE User_tbl SET date = GETDATE() WHERE id = @id";

            using (var connection = new SqlConnection(connect))
            {
                connection.Open();
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", userId);
                    command.ExecuteNonQuery();
                }
            }
        }



        private void CheckLastEnterDate(int userId)
        {
            string query = "SELECT date FROM User_tbl WHERE id = @id";

            DateTime lastEnter;
            using (var conn = new SqlConnection(connect))
            {
                conn.Open();
                using (var command = new SqlCommand(query, conn))
                {
                    command.Parameters.AddWithValue("@id", userId);
                    lastEnter = (DateTime)command.ExecuteScalar();
                }
            }

            TimeSpan checkDt = DateTime.Now - lastEnter;

            if (checkDt.Days > 30)
            {
                BlockUser(userId);
                throw new Exception("Вы не заходили более месяца и были заблокированы.");
            }
            else if (checkDt.Days > 14)
            {
                var updateForm = new UpdatePassword(userId);
                updateForm.ShowDialog();
            }
        }


        private string GetRoleUser(int userId)
        {
            string query = "SELECT role FROM User_tbl WHERE id = @id";

            using (var connection = new SqlConnection(connect))
            {
                connection.Open();
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", userId);
                    return (string)command.ExecuteScalar();
                }
            }
        }


        private void OpenUserForm(string role)
        {
            if (role == "Admin")
            {
                new Admin().ShowDialog();
            }
            else
            {
                new Root().ShowDialog();
            }
        }


        // Метод для проверки данных пользователя (логин и пароль)
        private void ValidLogOnPassInBD(string login, string password)
        {
            // Проверка входных данных
            int? userId = AuthenticateUser(login, password);

            if (userId == null)
            {
                FailAttemptEnter(login);
                throw new Exception("Неправильный логин или пароль");
            }

            int id = userId.Value;

            // Проверка активности пользователя
            if (!ActiveUser(id))
            {
                throw new Exception("Пользователь заблокирован");
            }

            // Обновление даты входа
            UpdateDateUser(id);

            // Проверка давности входа
            CheckLastEnterDate(id);

            // Получение роли и открытие формы
            string role = GetRoleUser(id);
            OpenUserForm(role);
        }





        private bool ExistsLogin(string login)
        {
            string query = "SELECT COUNT(1) FROM User_tbl WHERE Login = @login";

            using (var conn = new SqlConnection(connect))
            {
                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@login", login);
                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
        }


        // Метод для регистрации нового пользователя
        private bool Registr(string login, string password)
        {
            if (ExistsLogin(login))
            {
                return false;
            }

            string insertQuery = @"INSERT INTO dbo.User_tbl (login, password, Count, date, active, role) VALUES (@login, @password, 0, GETDATE(), 'True', 'User')";

            using (var conn = new SqlConnection(connect))
            {
                conn.Open();
                using (var cmd = new SqlCommand(insertQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@login", login);
                    cmd.Parameters.AddWithValue("@password", password);
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }

        }

        // Метод для проверки, что поля логина и пароля заполнены.
        private void CheckEmptyEntriesEnter(string login, string password)
        {
            if (login == "")
                throw new Exception("Поле <Логин> должно быть заполнено");
            if (password == "")
                throw new Exception("Поле <Пароль> должно быть заполнено");
        }



        // Метод для проверки, что поля логина, пароля и подтверждения пароля заполнены
        private void CheckEmptyReg(string login, string password, string confirm)
        {
            CheckEmptyEntriesEnter(login, password);
            if (confirm == "")
                throw new Exception("Поле <Подтверждение> должно быть заполнено");
        }



        // Обработчик события нажатия кнопки "Регистрация"
        private void reg_btn_Click(object sender, EventArgs e)
        {
       
            string login = Login.Text;
            string password = Password.Text;
            string confirm = PassRep.Text;

            try
            {
                CheckEmptyReg(login, password, confirm);

                if (Registr(login, password))
                {
                    MessageBox.Show("Пользователь добавлен!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearPoleReg();
                }
                else
                {
                    MessageBox.Show("Пользователь с таким логином уже существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    ClearPoleReg();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


      
        private void Authorization_frm_Load(object sender, EventArgs e)
        {
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
    }
}
